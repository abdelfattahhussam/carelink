import 'package:dio/dio.dart';
import '../../core/constants/api_endpoints.dart';
import '../../core/errors/failures.dart';
import '../models/request_model.dart';

/// Patient request API service
class RequestService {
  final Dio _dio;
  RequestService({required Dio dio}) : _dio = dio;

  /// Create a new medicine request
  Future<RequestModel> createRequest({
    required String medicineId,
    required String patientNationalId, // Added patient National ID
    required bool isUrgent,
    required String reason,
    String? prescriptionPath,
  }) async {
    final response = await _dio.post(
      ApiEndpoints.requests,
      data: {
        'medicineId': medicineId,
        'patientNationalId': patientNationalId,
        'quantity': 1,
        'isUrgent': isUrgent,
        'reason': reason,
        if (prescriptionPath != null) 'prescriptionPath': prescriptionPath,
      },
    );

    if (response.statusCode == 201 && response.data['success'] == true) {
      return RequestModel.fromJson(response.data['data']);
    }
    throw ServerFailure(message: response.data['error'] ?? 'Failed to create request');
  }

  /// Get all requests (filtered by role on server side)
  Future<List<RequestModel>> getRequests() async {
    final response = await _dio.get(ApiEndpoints.requests);

    if (response.statusCode == 200 && response.data['success'] == true) {
      final list = response.data['data'] as List;
      return list.map((e) => RequestModel.fromJson(e)).toList();
    }
    throw ServerFailure(message: 'Failed to fetch requests');
  }

  /// Approve or reject a patient request — pharmacist only
  Future<RequestModel> approveRequest({
    required String requestId,
    required String action, // 'approve' or 'reject'
  }) async {
    final response = await _dio.post(
      ApiEndpoints.approveRequest,
      data: {
        'requestId': requestId,
        'action': action,
      },
    );

    if (response.statusCode == 200 && response.data['success'] == true) {
      return RequestModel.fromJson(response.data['data']);
    }
    throw ServerFailure(message: response.data['error'] ?? 'Action failed');
  }
}
