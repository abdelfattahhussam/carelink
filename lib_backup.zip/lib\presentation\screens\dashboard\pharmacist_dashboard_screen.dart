import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/models/user_model.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../blocs/auth/auth_bloc.dart';
import '../../blocs/donation/donation_bloc.dart';
import '../../blocs/medicine/medicine_bloc.dart';
import '../../blocs/notification/notification_bloc.dart';
import '../../blocs/request/request_bloc.dart';

class PharmacistDashboardScreen extends StatefulWidget {
  const PharmacistDashboardScreen({super.key});
  @override
  State<PharmacistDashboardScreen> createState() =>
      _PharmacistDashboardScreenState();
}

class _PharmacistDashboardScreenState extends State<PharmacistDashboardScreen> {
  @override
  void initState() {
    super.initState();
    context.read<NotificationBloc>().add(NotificationsFetchRequested());
    context.read<MedicineBloc>().add(MedicinesFetchRequested());
    context.read<RequestBloc>().add(RequestsFetchRequested());
    final authState = context.read<AuthBloc>().state;
    if (authState is AuthAuthenticated) {
      context.read<DonationBloc>().add(PendingDonationsFetchRequested());
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, authState) {
        if (authState is! AuthAuthenticated) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        final user = authState.user;
        return Scaffold(
          appBar: HomeAppBar(user: user),
          body: RefreshIndicator(
            onRefresh: () async => _refreshData(user),
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildWelcomeCard(context, user),
                  const SizedBox(height: 24),
                  _buildStatsGrid(context, user),
                  const SizedBox(height: 24),
                  Text(
                    AppLocalizations.of(context)!.quickActions,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 12),
                  _buildQuickActions(context, user),
                ],
              ),
            ),
          ),
          bottomNavigationBar: _buildBottomNav(context, user),
        );
      },
    );
  }

  void _refreshData(UserModel user) {
    context.read<MedicineBloc>().add(MedicinesFetchRequested());
    context.read<NotificationBloc>().add(NotificationsFetchRequested());
    context.read<DonationBloc>().add(PendingDonationsFetchRequested());
    context.read<RequestBloc>().add(RequestsFetchRequested());
  }

  Widget _buildWelcomeCard(BuildContext context, UserModel user) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: AppColors.heroGradient,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            AppLocalizations.of(
              context,
            )!.welcomeWithName(user.name.split(' ').first),
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _getRoleMsg(context, user.role),
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.85),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              AppLocalizations.of(context)!.verifiedRole(user.role.label),
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.9),
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getRoleMsg(BuildContext context, UserRole role) => switch (role) {
    UserRole.pharmacist => AppLocalizations.of(context)!.pharmacistWelcome,
    _ => AppLocalizations.of(context)!.appTitle,
  };

  Widget _buildStatsGrid(BuildContext context, UserModel user) {
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.5,
      children: _statsForRole(user),
    );
  }

  List<Widget> _statsForRole(UserModel user) {
    return [
      _stat(
        AppLocalizations.of(context)!.pendingReviews,
        _donPending(),
        Icons.rate_review,
        AppColors.warning,
      ),
      _stat(
        AppLocalizations.of(context)!.myRequests,
        _reqCount(),
        Icons.list_alt,
        AppColors.primary,
      ),
      _stat(
        AppLocalizations.of(context)!.availableMedicines,
        _medCount(),
        Icons.medication,
        AppColors.secondary,
      ),
      _stat(
        AppLocalizations.of(context)!.urgent,
        _urgentCount(),
        Icons.priority_high,
        AppColors.error,
      ),
    ];
  }

  Widget _stat(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.divider.withValues(alpha: 0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, size: 18, color: color),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          Text(
            label,
            style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  String _donPending() {
    final s = context.watch<DonationBloc>().state;
    return s is DonationsLoaded
        ? '${s.donations.where((d) => d.isPending).length}'
        : '0';
  }

  String _medCount() {
    final s = context.watch<MedicineBloc>().state;
    return s is MedicinesLoaded ? '${s.medicines.length}' : '0';
  }

  String _reqCount() {
    final s = context.watch<RequestBloc>().state;
    return s is RequestsLoaded ? '${s.requests.length}' : '0';
  }

  String _urgentCount() {
    final s = context.watch<RequestBloc>().state;
    return s is RequestsLoaded
        ? '${s.requests.where((r) => r.isUrgent).length}'
        : '0';
  }

  Widget _buildQuickActions(BuildContext context, UserModel user) {
    final actions = [
      (
        AppLocalizations.of(context)!.reviewDonations,
        Icons.rate_review,
        AppColors.primary,
        '/review',
      ),
      (
        AppLocalizations.of(context)!.manageRequests,
        Icons.list_alt,
        AppColors.secondary,
        '/manage-requests',
      ),
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.8,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      children: actions
          .map(
            (a) => GestureDetector(
              onTap: () => context.push(a.$4),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: a.$3.withValues(alpha: 0.06),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: a.$3.withValues(alpha: 0.15)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: a.$3.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(a.$2, color: a.$3, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        a.$1,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _buildBottomNav(BuildContext context, UserModel user) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _navItem(
                context,
                Icons.medication_outlined,
                AppLocalizations.of(context)!.medicines,
                () => context.push('/medicines'),
              ),
              _navItem(
                context,
                Icons.qr_code_scanner,
                AppLocalizations.of(context)!.scan,
                () => context.push('/qr-scan'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(
    BuildContext context,
    IconData icon,
    String label,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppColors.textLight, size: 26),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textLight,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
