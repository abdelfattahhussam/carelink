import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/date_formatters.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../../core/widgets/shimmer_loading.dart';
import '../../blocs/request/request_bloc.dart';

/// Shows patient's own requests with status tracking
class MyRequestsScreen extends StatefulWidget {
  const MyRequestsScreen({super.key});
  @override
  State<MyRequestsScreen> createState() => _MyRequestsScreenState();
}

class _MyRequestsScreenState extends State<MyRequestsScreen> {
  @override
  void initState() { super.initState(); context.read<RequestBloc>().add(RequestsFetchRequested()); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.myRequests), leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 20), onPressed: () => context.pop())),
      body: BlocBuilder<RequestBloc, RequestState>(
        builder: (context, state) {
          Widget child;
          if (state is RequestLoading) {
            child = const ShimmerCardList(key: ValueKey('loading'), isListTileStyle: false);
          } else if (state is RequestError) {
            child = Center(key: const ValueKey('error'), child: Text(state.message));
          } else if (state is RequestsLoaded) {
            if (state.requests.isEmpty) {
              child = EmptyStateWidget(key: const ValueKey('empty'), icon: Icons.inbox, title: AppLocalizations.of(context)!.noRequestsYet, subtitle: AppLocalizations.of(context)!.browseMedicinesAndSubmit);
            } else {
              child = ListView.builder(
                key: const ValueKey('list'),
                padding: const EdgeInsets.all(16), itemCount: state.requests.length,
                itemBuilder: (context, i) {
                  final r = state.requests[i];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Container(padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(color: r.isUrgent ? AppColors.error.withValues(alpha: 0.1) : AppColors.primaryContainer, borderRadius: BorderRadius.circular(12)),
                            child: Icon(r.isUrgent ? Icons.priority_high : Icons.medication, color: r.isUrgent ? AppColors.error : AppColors.primary)),
                          const SizedBox(width: 14),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Expanded(child: Text(r.medicineName, style: const TextStyle(fontWeight: FontWeight.w600))),
                              if (r.isUrgent) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(color: AppColors.error.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                                child: Text(AppLocalizations.of(context)!.urgent, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.error))),
                            ]),
                            const SizedBox(height: 4),
                            Text(
                              "${r.quantity} ${r.unit.localizedName(context)} • ${DateFormatters.timeAgo(r.createdAt)}", 
                              style: TextStyle(fontSize: 12, color: AppColors.textLight)
                            ),
                          ])),
                        ]),
                        const SizedBox(height: 12),
                        Row(children: [
                          StatusBadge(status: r.status),
                          const Spacer(),
                          if (r.hasQrCode)
                            GestureDetector(
                              onTap: () => context.push('/qr-display', extra: r.qrCode),
                              child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(8)),
                                child: Row(mainAxisSize: MainAxisSize.min, children: [
                                  const Icon(Icons.qr_code, size: 16, color: Colors.white),
                                  const SizedBox(width: 4),
                                  Text(AppLocalizations.of(context)!.showQr, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white)),
                                ]),
                              ),
                            ),
                        ]),
                      ]),
                    ),
                  );
                },
              );
            }
          } else {
            child = const SizedBox.shrink(key: ValueKey('none'));
          }

          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: child,
          );
        },
      ),
    );
  }
}
