import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../blocs/auth/auth_bloc.dart';
import '../../../data/models/user_model.dart';
import 'package:image_picker/image_picker.dart';

/// Registration screen with role selection
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _nationalIdController = TextEditingController(); // Added controller for National ID
  
  // Pharmacist specific controllers
  final _pharmacyNameController = TextEditingController();
  final _governorateController = TextEditingController();
  final _cityController = TextEditingController();
  final _villageController = TextEditingController();
  final _streetController = TextEditingController();
  
  String? _licensePath;
  bool _obscurePassword = true;
  UserRole _selectedRole = UserRole.patient;

  final ImagePicker _picker = ImagePicker();



  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _pharmacyNameController.dispose();
    _governorateController.dispose();
    _cityController.dispose();
    _villageController.dispose();
    _streetController.dispose();
    _nationalIdController.dispose();
    super.dispose();
  }

  Future<void> _pickLicenseImage() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
    );
    if (image != null) {
      setState(() => _licensePath = image.path);
    }
  }

  void _submit() {
    if (_formKey.currentState?.validate() ?? false) {
      if (_selectedRole == UserRole.pharmacist && _licensePath == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(AppLocalizations.of(context)!.licenseRequired),
            backgroundColor: AppColors.error,
          ),
        );
        return;
      }

      context.read<AuthBloc>().add(
            AuthRegisterRequested(
              name: _nameController.text.trim(),
              email: _emailController.text.trim(),
              phone: _phoneController.text.trim(),
              nationalId: _nationalIdController.text.trim(),
              password: _passwordController.text,
              role: _selectedRole,
              pharmacyName: _selectedRole == UserRole.pharmacist ? _pharmacyNameController.text.trim() : null,
              governorate: _governorateController.text.trim(),
              city: _cityController.text.trim(),
              village: _villageController.text.trim(),
              street: _streetController.text.trim(),
              licensePath: _selectedRole == UserRole.pharmacist ? _licensePath : null,
            ),
          );
    }
  }

  @override
  Widget build(BuildContext context) {
    final roles = [
      {'value': UserRole.donor, 'label': AppLocalizations.of(context)!.donor, 'icon': Icons.volunteer_activism},
      {'value': UserRole.patient, 'label': AppLocalizations.of(context)!.patient, 'icon': Icons.person},
      {'value': UserRole.pharmacist, 'label': AppLocalizations.of(context)!.pharmacist, 'icon': Icons.medical_services},
    ];

    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is AuthError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: AppColors.error,
            ),
          );
        }
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, size: 20),
            onPressed: () => context.pop(),
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 8),
                  Text(
                    AppLocalizations.of(context)!.createAccount,
                    style: Theme.of(context).textTheme.headlineLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Join ${AppLocalizations.of(context)!.appTitle} and make a difference',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 32),
                  // Role selection
                  Text(
                    AppLocalizations.of(context)!.selectRole,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: roles.map((role) {
                      final isSelected = _selectedRole == role['value'];
                      return Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() => _selectedRole = role['value'] as UserRole),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? AppColors.primary.withValues(alpha: 0.1)
                                  : AppColors.surfaceVariant,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: isSelected
                                    ? AppColors.primary
                                    : AppColors.divider,
                                width: isSelected ? 2 : 1,
                              ),
                            ),
                            child: Column(
                              children: [
                                Icon(
                                  role['icon'] as IconData,
                                  color: isSelected
                                      ? AppColors.primary
                                      : AppColors.textLight,
                                  size: 28,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  role['label'] as String,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: isSelected
                                        ? FontWeight.w600
                                        : FontWeight.w400,
                                    color: isSelected
                                        ? AppColors.primary
                                        : AppColors.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 24),

                  // Name
                  AppTextField(
                    controller: _nameController,
                    label: AppLocalizations.of(context)!.fullName,
                    hint: AppLocalizations.of(context)!.fullName,
                    prefixIcon: Icons.person_outline,
                    validator: (v) => Validators.required(v, AppLocalizations.of(context)!.name),
                  ),
                  const SizedBox(height: 16),

                  // Email
                  AppTextField(
                    controller: _emailController,
                    label: AppLocalizations.of(context)!.email,
                    hint: AppLocalizations.of(context)!.email,
                    prefixIcon: Icons.email_outlined,
                    keyboardType: TextInputType.emailAddress,
                    validator: Validators.email,
                  ),
                  const SizedBox(height: 16),

                  // Phone
                  AppTextField(
                    controller: _phoneController,
                    label: AppLocalizations.of(context)!.phone,
                    hint: '+20 1234567890',
                    prefixIcon: Icons.phone_outlined,
                    keyboardType: TextInputType.phone,
                    validator: Validators.phone,
                  ),
                  const SizedBox(height: 16),

                  // National ID (Visible for everyone)
                  AppTextField(
                    controller: _nationalIdController,
                    label: AppLocalizations.of(context)!.nationalId,
                    hint: '29901011234567',
                    prefixIcon: Icons.badge_outlined,
                    keyboardType: TextInputType.number,
                    validator: (v) => Validators.nationalId(
                      v, 
                      AppLocalizations.of(context)!.nationalIdRequired,
                      AppLocalizations.of(context)!.nationalIdInvalid,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Address section (Visible for everyone)
                  const Divider(height: 32),
                  Text(
                    _selectedRole == UserRole.pharmacist 
                        ? AppLocalizations.of(context)!.addressInfo 
                        : AppLocalizations.of(context)!.address,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(color: AppColors.primary),
                  ),
                  const SizedBox(height: 12),
                  AppTextField(
                    controller: _governorateController,
                    label: AppLocalizations.of(context)!.governorate,
                    hint: AppLocalizations.of(context)!.governorate,
                    validator: (v) => Validators.required(v, AppLocalizations.of(context)!.governorate),
                  ),
                  const SizedBox(height: 16),
                  AppTextField(
                    controller: _cityController,
                    label: AppLocalizations.of(context)!.city,
                    hint: AppLocalizations.of(context)!.city,
                    validator: (v) => Validators.required(v, AppLocalizations.of(context)!.city),
                  ),
                  const SizedBox(height: 16),
                  AppTextField(
                    controller: _villageController,
                    label: AppLocalizations.of(context)!.village,
                    hint: AppLocalizations.of(context)!.village,
                  ),
                  const SizedBox(height: 16),
                  AppTextField(
                    controller: _streetController,
                    label: AppLocalizations.of(context)!.street,
                    hint: AppLocalizations.of(context)!.street,
                    validator: (v) => Validators.required(v, AppLocalizations.of(context)!.street),
                  ),
                  const SizedBox(height: 24),

                  // Pharmacist extra fields
                  if (_selectedRole == UserRole.pharmacist) ...[
                    Text(
                      AppLocalizations.of(context)!.pharmacyName,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(color: AppColors.primary),
                    ),
                    const SizedBox(height: 12),
                    AppTextField(
                      controller: _pharmacyNameController,
                      label: AppLocalizations.of(context)!.pharmacyName,
                      hint: AppLocalizations.of(context)!.pharmacyName,
                      prefixIcon: Icons.local_pharmacy_outlined,
                      validator: (v) => Validators.required(v, AppLocalizations.of(context)!.pharmacyName),
                    ),
                    const SizedBox(height: 24),

                    // License upload
                    InkWell(
                      onTap: _pickLicenseImage,
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withValues(alpha: 0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              _licensePath != null ? Icons.check_circle : Icons.upload_file_outlined,
                              color: _licensePath != null ? AppColors.success : AppColors.primary,
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Text(
                                _licensePath != null
                                    ? _licensePath!.split('/').last
                                    : AppLocalizations.of(context)!.uploadLicense,
                                style: const TextStyle(fontWeight: FontWeight.w500),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Divider(height: 32),
                  ],

                  // Password
                  AppTextField(
                    controller: _passwordController,
                    label: AppLocalizations.of(context)!.password,
                    hint: AppLocalizations.of(context)!.password,
                    prefixIcon: Icons.lock_outline,
                    obscureText: _obscurePassword,
                    validator: Validators.password,
                    suffix: IconButton(
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: AppColors.textLight,
                        size: 22,
                      ),
                      onPressed: () =>
                          setState(() => _obscurePassword = !_obscurePassword),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Confirm Password
                  AppTextField(
                    controller: _confirmPasswordController,
                    label: AppLocalizations.of(context)!.confirmPassword,
                    hint: AppLocalizations.of(context)!.confirmPassword,
                    prefixIcon: Icons.lock_outline,
                    obscureText: true,
                    validator: (v) =>
                        Validators.confirmPassword(v, _passwordController.text),
                  ),
                  const SizedBox(height: 32),

                  // Register button
                  BlocBuilder<AuthBloc, AuthState>(
                    builder: (context, state) {
                      return AppButton(
                        text: AppLocalizations.of(context)!.signUp,
                        isLoading: state is AuthLoading,
                        onPressed: _submit,
                      );
                    },
                  ),
                  const SizedBox(height: 24),

                  // Login link
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        AppLocalizations.of(context)!.hasAccount,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      GestureDetector(
                        onTap: () => context.pop(),
                        child: Text(
                          AppLocalizations.of(context)!.signIn,
                          style: TextStyle(
                            color: AppColors.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
