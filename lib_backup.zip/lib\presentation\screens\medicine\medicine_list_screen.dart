import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/date_formatters.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../../data/models/user_model.dart';
import '../../blocs/auth/auth_bloc.dart';
import '../../blocs/medicine/medicine_bloc.dart';

class MedicineListScreen extends StatefulWidget {
  const MedicineListScreen({super.key});
  @override
  State<MedicineListScreen> createState() => _MedicineListScreenState();
}

class _MedicineListScreenState extends State<MedicineListScreen> {
  final _searchCtrl = TextEditingController();

  bool get _isPatient {
    final authState = context.read<AuthBloc>().state;
    return authState is AuthAuthenticated && authState.user.role == UserRole.patient;
  }

  @override
  void initState() {
    super.initState();
    context.read<MedicineBloc>().add(MedicinesFetchRequested());
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _search(String query) {
    if (query.isEmpty) {
      context.read<MedicineBloc>().add(MedicinesFetchRequested());
    } else {
      context.read<MedicineBloc>().add(MedicinesSearchRequested(query: query));
    }
  }

  void _showMedicineDetails(BuildContext context, dynamic medicine) {
    final l10n = AppLocalizations.of(context)!;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: AppColors.primaryContainer,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(
                    Icons.medication,
                    color: AppColors.primary,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        medicine.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 17,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        medicine.category,
                        style: TextStyle(
                          fontSize: 13,
                          color: AppColors.textLight,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              medicine.description,
              style: TextStyle(
                fontSize: 14,
                color: AppColors.textSecondary,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (!_isPatient)
                  _detailChip(
                    Icons.inventory_2,
                    "${medicine.quantity} ${medicine.unit.localizedName(context)}",
                    AppColors.success,
                  )
                else
                  _detailChip(
                    Icons.inventory_2,
                    medicine.inStock ? l10n.available : l10n.outOfStock,
                    medicine.inStock ? AppColors.success : AppColors.error,
                  ),
                _detailChip(
                  Icons.event,
                  l10n.expDate(DateFormatters.formatDate(medicine.expiryDate)),
                  AppColors.info,
                ),
                _detailChip(
                  Icons.category,
                  medicine.category,
                  AppColors.secondary,
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                  child: Text(l10n.cancel),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: medicine.inStock && !medicine.isExpired
                        ? () {
                            Navigator.pop(context);
                            this.context.push('/request/${medicine.id}', extra: medicine);
                          }
                        : null,
                    icon: const Icon(Icons.send, size: 18),
                    label: Text(l10n.requestMedicine),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: AppColors.textLight.withValues(alpha: 0.2),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailChip(IconData icon, String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: color),
        const SizedBox(width: 6),
        Text(
          text,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Medicines'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, size: 20),
          onPressed: () => context.pop(),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (query) {
                setState(() {});
                _search(query);
              },
              decoration: InputDecoration(
                hintText: AppLocalizations.of(context)!.searchMedicines,
                prefixIcon: const Icon(
                  Icons.search,
                  color: AppColors.textLight,
                ),
                suffixIcon: _searchCtrl.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 20),
                        onPressed: () {
                          _searchCtrl.clear();
                          _search('');
                        },
                      )
                    : null,
              ),
            ),
          ),
          Expanded(
            child: BlocBuilder<MedicineBloc, MedicineState>(
              builder: (context, state) {
                if (state is MedicineLoading)
                  return const Center(child: CircularProgressIndicator());
                if (state is MedicineError)
                  return Center(child: Text(state.message));
                if (state is MedicinesLoaded) {
                  if (state.medicines.isEmpty) {
                    return EmptyStateWidget(
                      icon: Icons.medication_outlined,
                      title: AppLocalizations.of(context)!.noMedicinesFound,
                      subtitle: AppLocalizations.of(
                        context,
                      )!.tryDifferentSearch,
                    );
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: state.medicines.length,
                    itemBuilder: (context, i) {
                      final m = state.medicines[i];
                      return Card(
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => _showMedicineDetails(context, m),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              children: [
                                Container(
                                  width: 56,
                                  height: 56,
                                  decoration: BoxDecoration(
                                    color: m.inStock
                                        ? AppColors.primaryContainer
                                        : AppColors.surfaceVariant,
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: Icon(
                                    Icons.medication,
                                    color: m.inStock
                                        ? AppColors.primary
                                        : AppColors.textLight,
                                    size: 28,
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              m.name,
                                              style: const TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 15,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        m.category,
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: AppColors.textLight,
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      Wrap(
                                        spacing: 8,
                                        runSpacing: 4,
                                        children: [
                                          if (!m.inStock)
                                            _tag(
                                              AppLocalizations.of(
                                                context,
                                              )!.outOfStock,
                                              AppColors.error,
                                            )
                                          else if (!_isPatient)
                                            _tag(
                                              "${m.quantity} ${m.unit.localizedName(context)}",
                                              AppColors.success,
                                            )
                                          else
                                            _tag(
                                              AppLocalizations.of(
                                                context,
                                              )!.available,
                                              AppColors.success,
                                            ),
                                          if (m.isExpired)
                                            _tag(
                                              AppLocalizations.of(
                                                context,
                                              )!.expired,
                                              AppColors.expired,
                                            )
                                          else
                                            _tag(
                                              AppLocalizations.of(
                                                context,
                                              )!.expDate(
                                                DateFormatters.formatDate(
                                                  m.expiryDate,
                                                ),
                                              ),
                                              AppColors.info,
                                            ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                const Icon(
                                  Icons.chevron_right,
                                  color: AppColors.textLight,
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _tag(String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(
      text,
      style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: color),
    ),
  );
}
