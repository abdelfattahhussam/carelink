import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/date_formatters.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../../core/widgets/shimmer_loading.dart';
import '../../blocs/request/request_bloc.dart';

/// Pharmacist screen to manage patient requests
class ManageRequestsScreen extends StatefulWidget {
  const ManageRequestsScreen({super.key});
  @override
  State<ManageRequestsScreen> createState() => _ManageRequestsScreenState();
}

class _ManageRequestsScreenState extends State<ManageRequestsScreen> {
  @override
  void initState() { super.initState(); context.read<RequestBloc>().add(RequestsFetchRequested()); }

  void _action(String requestId, String action) {
    final reviewAction = action == 'approve' ? RequestReviewAction.approve : RequestReviewAction.reject;
    context.read<RequestBloc>().add(RequestApproveRequested(requestId: requestId, action: reviewAction));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.manageRequests), leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 20), onPressed: () => context.pop())),
      body: BlocConsumer<RequestBloc, RequestState>(
        listener: (context, state) {
          if (state is RequestActionCompleted) {
            final msg = state.action == 'approve' ? AppLocalizations.of(context)!.requestApprovedQrGenerated : AppLocalizations.of(context)!.requestRejected;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: state.action == 'approve' ? AppColors.success : AppColors.error));
            context.read<RequestBloc>().add(RequestsFetchRequested());
          }
        },
        builder: (context, state) {
          Widget child;
          if (state is RequestLoading) {
            child = const ShimmerCardList(key: ValueKey('loading'), isListTileStyle: false);
          } else if (state is RequestsLoaded) {
            if (state.requests.isEmpty) {
              child = EmptyStateWidget(key: const ValueKey('empty'), icon: Icons.inbox, title: AppLocalizations.of(context)!.noRequests, subtitle: AppLocalizations.of(context)!.noPatientRequestsAtMoment);
            } else {
              child = ListView.builder(
                key: const ValueKey('list'),
                padding: const EdgeInsets.all(16), itemCount: state.requests.length,
                itemBuilder: (context, i) {
                  final r = state.requests[i];
                  return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(color: (r.isUrgent ? AppColors.error : AppColors.secondary).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
                        child: Icon(r.isUrgent ? Icons.priority_high : Icons.person, color: r.isUrgent ? AppColors.error : AppColors.secondary)),
                      const SizedBox(width: 14),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(child: Text(r.patientName, style: const TextStyle(fontWeight: FontWeight.w600))),
                          if (r.isUrgent) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: AppColors.error.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                            child: Text(AppLocalizations.of(context)!.urgent, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.error))),
                        ]),
                        Text(
                          '${r.medicineName} × ${r.quantity} ${r.unit.localizedName(context)}', 
                          style: TextStyle(fontSize: 13, color: AppColors.textSecondary)
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.badge_outlined, size: 14, color: AppColors.primary),
                              const SizedBox(width: 6),
                              Text(
                                '${AppLocalizations.of(context)!.nationalId}: ${r.patientNationalId}',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.primary),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text('${r.reason} • ${DateFormatters.timeAgo(r.createdAt)}', style: TextStyle(fontSize: 11, color: AppColors.textLight), maxLines: 1, overflow: TextOverflow.ellipsis),
                      ])),
                    ]),
                    const SizedBox(height: 12),
                    Row(children: [
                      StatusBadge(status: r.status),
                      const Spacer(),
                      if (r.isPending) ...[
                        IconButton(icon: const Icon(Icons.close, color: AppColors.error), onPressed: () => _action(r.id, 'reject'), tooltip: 'Reject'),
                        const SizedBox(width: 4),
                        IconButton(
                          icon: Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: AppColors.success, shape: BoxShape.circle),
                            child: const Icon(Icons.check, color: Colors.white, size: 18)),
                          onPressed: () => _action(r.id, 'approve'), tooltip: 'Approve'),
                      ],
                    ]),
                  ])));
                },
              );
            }
          } else if (state is RequestError) {
            child = Center(
              key: const ValueKey('error'),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.wifi_off_rounded, size: 64, color: AppColors.textLight),
                  const SizedBox(height: 16),
                  Text(state.message, textAlign: TextAlign.center,
                      style: const TextStyle(color: AppColors.textSecondary)),
                  const SizedBox(height: 24),
                  TextButton.icon(
                    icon: const Icon(Icons.refresh),
                    label: const Text('Retry'),
                    onPressed: () => context.read<RequestBloc>().add(RequestsFetchRequested()),
                  ),
                ],
              ),
            );
          } else {
            child = const SizedBox.shrink(key: ValueKey('none'));
          }

          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: child,
          );
        },
      ),
    );
  }
}
