import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/date_formatters.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../../core/widgets/shimmer_loading.dart';
import '../../blocs/donation/donation_bloc.dart';

/// Shows the list of donor's own donations with status
class MyDonationsScreen extends StatefulWidget {
  const MyDonationsScreen({super.key});
  @override
  State<MyDonationsScreen> createState() => _MyDonationsScreenState();
}

class _MyDonationsScreenState extends State<MyDonationsScreen> {
  @override
  void initState() { super.initState(); context.read<DonationBloc>().add(DonationsFetchRequested()); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.myDonations), leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 20), onPressed: () => context.pop())),
      body: BlocBuilder<DonationBloc, DonationState>(
        builder: (context, state) {
          Widget child;
          if (state is DonationLoading) {
            child = const ShimmerCardList(key: ValueKey('loading'), isListTileStyle: true);
          } else if (state is DonationError) {
            child = Center(key: const ValueKey('error'), child: Text(state.message));
          } else if (state is DonationsLoaded) {
            if (state.donations.isEmpty) {
              child = EmptyStateWidget(key: const ValueKey('empty'), icon: Icons.volunteer_activism, title: AppLocalizations.of(context)!.noDonationsYet, subtitle: AppLocalizations.of(context)!.startByDonating);
            } else {
              child = ListView.builder(
                key: const ValueKey('list'),
                padding: const EdgeInsets.all(16), itemCount: state.donations.length,
                itemBuilder: (context, i) {
                  final d = state.donations[i];
                  return Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16),
                      leading: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(color: AppColors.primaryContainer, borderRadius: BorderRadius.circular(12)),
                        child: const Icon(Icons.medication, color: AppColors.primary),
                      ),
                      title: Text(d.medicineName, style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const SizedBox(height: 4),
                        Text(
                          "${d.quantity} ${d.unit.localizedName(context)} • ${DateFormatters.timeAgo(d.createdAt)}",
                          style: TextStyle(fontSize: 12, color: AppColors.textLight)
                        ),
                        const SizedBox(height: 8),
                        Row(children: [
                          StatusBadge(status: d.status),
                          if (d.hasQrCode) ...[
                            const SizedBox(width: 8),
                            GestureDetector(
                              onTap: () => context.push('/qr-display', extra: d.qrCode),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(color: AppColors.info.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                                child: Row(mainAxisSize: MainAxisSize.min, children: [
                                  Icon(Icons.qr_code, size: 14, color: AppColors.info),
                                  const SizedBox(width: 4),
                                  Text(AppLocalizations.of(context)!.qr, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.info)),
                                ]),
                              ),
                            ),
                          ],
                        ]),
                      ]),
                    ),
                  );
                },
              );
            }
          } else {
            child = const SizedBox.shrink(key: ValueKey('none'));
          }

          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: child,
          );
        },
      ),
    );
  }
}
