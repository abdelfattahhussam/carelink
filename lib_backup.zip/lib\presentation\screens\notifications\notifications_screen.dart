import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/date_formatters.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../../data/models/notification_model.dart';
import '../../blocs/notification/notification_bloc.dart';

/// Notifications screen — shows all user notifications
class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void initState() { super.initState(); context.read<NotificationBloc>().add(NotificationsFetchRequested()); }

  IconData _iconForType(NotificationType type) => switch (type) {
    NotificationType.donationApproved => Icons.check_circle,
    NotificationType.newRequest => Icons.inbox,
    NotificationType.requestApproved => Icons.thumb_up,
    NotificationType.expiryWarning => Icons.warning_amber,
  };

  Color _colorForType(NotificationType type) => switch (type) {
    NotificationType.donationApproved => AppColors.success,
    NotificationType.newRequest => AppColors.info,
    NotificationType.requestApproved => AppColors.primary,
    NotificationType.expiryWarning => AppColors.warning,
  };

  String _getLocalizedTitle(BuildContext context, NotificationModel n) {
    final l10n = AppLocalizations.of(context)!;
    return switch (n.type) {
      NotificationType.donationApproved => l10n.notifDonationApprovedTitle,
      NotificationType.newRequest => l10n.notifNewRequestTitle,
      NotificationType.requestApproved => l10n.notifRequestApprovedTitle,
      NotificationType.expiryWarning => l10n.notifExpiryWarningTitle,
    };
  }

  String _getLocalizedBody(BuildContext context, NotificationModel n) {
    final l10n = AppLocalizations.of(context)!;
    return switch (n.type) {
      NotificationType.donationApproved => l10n.notifDonationApprovedBody,
      NotificationType.newRequest => l10n.notifNewRequestBody,
      NotificationType.requestApproved => l10n.notifRequestApprovedBody,
      NotificationType.expiryWarning => l10n.notifExpiryWarningBody,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.notifications),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 20), onPressed: () => context.pop()),
      ),
      body: BlocBuilder<NotificationBloc, NotificationState>(
        builder: (context, state) {
          if (state is NotificationLoading) return const Center(child: CircularProgressIndicator());
          if (state is NotificationError) return Center(child: Text(state.message));
          if (state is NotificationsLoaded) {
            if (state.notifications.isEmpty) return EmptyStateWidget(icon: Icons.notifications_off_outlined, title: AppLocalizations.of(context)!.noNotificationsTitle, subtitle: AppLocalizations.of(context)!.youAreAllCaughtUp);
            return ListView.builder(
              padding: const EdgeInsets.all(16), itemCount: state.notifications.length,
              itemBuilder: (context, i) {
                final n = state.notifications[i];
                final color = _colorForType(n.type);
                return Dismissible(
                  key: Key(n.id),
                  background: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    decoration: BoxDecoration(color: AppColors.success.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(16)),
                    alignment: AlignmentDirectional.centerEnd, padding: const EdgeInsetsDirectional.only(end: 20),
                    child: const Icon(Icons.done_all, color: AppColors.success),
                  ),
                  onDismissed: (_) => context.read<NotificationBloc>().add(NotificationDismissRequested(notificationId: n.id)),
                  child: InkWell(
                    onTap: () {
                      // Navigate based on notification type
                      switch (n.type) {
                        case NotificationType.donationApproved:
                          context.push('/my-donations');
                        case NotificationType.newRequest:
                          context.push('/manage-requests');
                        case NotificationType.requestApproved:
                          context.push('/my-requests');
                        case NotificationType.expiryWarning:
                          context.push('/medicines');
                      }
                      
                      // Mark as read when clicked
                      if (!n.isRead) {
                        context.read<NotificationBloc>().add(NotificationMarkReadRequested(notificationId: n.id));
                      }
                    },
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: n.isRead ? AppColors.card : color.withValues(alpha: 0.04),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: n.isRead ? AppColors.divider.withValues(alpha: 0.5) : color.withValues(alpha: 0.2)),
                      ),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
                          child: Icon(_iconForType(n.type), color: color, size: 22),
                        ),
                        const SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Expanded(child: Text(_getLocalizedTitle(context, n), style: TextStyle(fontWeight: n.isRead ? FontWeight.w500 : FontWeight.w600, fontSize: 14))),
                            if (!n.isRead) Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                          ]),
                          const SizedBox(height: 4),
                          Text(_getLocalizedBody(context, n), style: TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.4)),
                          const SizedBox(height: 6),
                          Text(DateFormatters.timeAgo(n.createdAt), style: TextStyle(fontSize: 11, color: AppColors.textLight)),
                        ])),
                      ]),
                    ),
                  ),
                );
              },
            );
          }
          return const SizedBox.shrink();
        },
      ),
    );
  }
}
