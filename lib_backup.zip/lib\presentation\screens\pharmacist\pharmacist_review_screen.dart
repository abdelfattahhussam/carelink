import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/date_formatters.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../../core/widgets/shimmer_loading.dart';
import '../../blocs/donation/donation_bloc.dart';

/// Pharmacist review screen — approve/reject pending donations
class PharmacistReviewScreen extends StatefulWidget {
  const PharmacistReviewScreen({super.key});
  @override
  State<PharmacistReviewScreen> createState() => _PharmacistReviewScreenState();
}

class _PharmacistReviewScreenState extends State<PharmacistReviewScreen> {
  @override
  void initState() { super.initState(); context.read<DonationBloc>().add(PendingDonationsFetchRequested()); }

  void _review(String donationId, String action) {
    showDialog(context: context, builder: (ctx) {
      final notesCtrl = TextEditingController();
      return AlertDialog(
        title: Text('${action[0].toUpperCase()}${action.substring(1)} Donation'),
        content: StatefulBuilder(
          builder: (context, _) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Are you sure you want to $action this donation?'),
                const SizedBox(height: 16),
                TextField(
                  controller: notesCtrl,
                  decoration: InputDecoration(hintText: AppLocalizations.of(context)!.addReviewNotesOptional),
                  maxLines: 2,
                ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () {
              notesCtrl.dispose();
              Navigator.pop(ctx);
            },
            child: Text(AppLocalizations.of(context)!.cancel),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: action == 'approve' ? AppColors.success : AppColors.error),
            onPressed: () {
              final notes = notesCtrl.text;
              notesCtrl.dispose();
              Navigator.pop(ctx);
              final reviewAction = action == 'approve' ? DonationReviewAction.approve : DonationReviewAction.reject;
              context.read<DonationBloc>().add(DonationReviewRequested(donationId: donationId, action: reviewAction, notes: notes));
            },
            child: Text(action[0].toUpperCase() + action.substring(1)),
          ),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.reviewDonations), leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 20), onPressed: () => context.pop())),
      body: BlocConsumer<DonationBloc, DonationState>(
        listener: (context, state) {
          if (state is DonationReviewed) {
            final msg = state.action == DonationReviewAction.approve ? 'Donation approved! QR code generated.' : 'Donation rejected.';
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: state.action == DonationReviewAction.approve ? AppColors.success : AppColors.error));
            context.read<DonationBloc>().add(PendingDonationsFetchRequested());
          }
        },
        builder: (context, state) {
          Widget child;
          if (state is DonationLoading) {
            child = const ShimmerCardList(key: ValueKey('loading'), isListTileStyle: false);
          } else if (state is DonationError) {
            child = Center(key: const ValueKey('error'), child: Text(state.message));
          } else if (state is DonationsLoaded) {
            if (state.donations.isEmpty) {
              child = EmptyStateWidget(key: const ValueKey('empty'), icon: Icons.rate_review, title: AppLocalizations.of(context)!.allCaughtUp, subtitle: AppLocalizations.of(context)!.noPendingDonations);
            } else {
              child = ListView.builder(
                key: const ValueKey('list'),
                padding: const EdgeInsets.all(16), itemCount: state.donations.length,
                itemBuilder: (context, i) {
                  final d = state.donations[i];
                  return Card(
                    child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Container(padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: AppColors.warning.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
                          child: const Icon(Icons.medication, color: AppColors.warning)),
                        const SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(d.medicineName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                          const SizedBox(height: 4),
                            Text(
                              "${AppLocalizations.of(context)!.byNameQty(d.donorName, d.quantity.toString())} ${d.unit.localizedName(context)}",
                              style: TextStyle(fontSize: 12, color: AppColors.textLight)
                            ),
                            Text(DateFormatters.timeAgo(d.createdAt), style: TextStyle(fontSize: 11, color: AppColors.textLight)),
                        ])),
                        const StatusBadge(status: 'pending'),
                      ]),
                      const SizedBox(height: 16),
                      Row(children: [
                        Expanded(child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(foregroundColor: AppColors.error, side: const BorderSide(color: AppColors.error)),
                          onPressed: () => _review(d.id, 'reject'),
                          icon: const Icon(Icons.close, size: 18), label: Text(AppLocalizations.of(context)!.reject),
                        )),
                        const SizedBox(width: 12),
                        Expanded(child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(backgroundColor: AppColors.success),
                          onPressed: () => _review(d.id, 'approve'),
                          icon: const Icon(Icons.check, size: 18), label: Text(AppLocalizations.of(context)!.approve),
                        )),
                      ]),
                    ])),
                  );
                },
              );
            }
          } else {
            child = const SizedBox.shrink(key: ValueKey('none'));
          }

          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: child,
          );
        },
      ),
    );
  }
}
