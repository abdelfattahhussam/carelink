import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';

/// Displays a QR code for pickup/delivery confirmation
class QrDisplayScreen extends StatelessWidget {
  final String? qrData;
  const QrDisplayScreen({super.key, this.qrData});

  @override
  Widget build(BuildContext context) {
    final code = qrData ?? 'NO-QR-DATA';
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.qrCode),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 20), onPressed: () => context.pop()),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(24),
                boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.15), blurRadius: 30, offset: const Offset(0, 10))],
              ),
              child: Column(children: [
                // Header
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(gradient: AppColors.heroGradient, borderRadius: BorderRadius.circular(10)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.local_pharmacy_rounded, color: Colors.white, size: 18),
                    SizedBox(width: 8),
                    Text(AppLocalizations.of(context)!.carelink, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
                  ]),
                ),
                const SizedBox(height: 24),
                // QR Code
                QrImageView(data: code, version: QrVersions.auto, size: 220, eyeStyle: QrEyeStyle(eyeShape: QrEyeShape.square, color: AppColors.primaryDark),
                  dataModuleStyle: QrDataModuleStyle(dataModuleShape: QrDataModuleShape.square, color: AppColors.textPrimary)),
                const SizedBox(height: 20),
                // Code text
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(color: AppColors.surfaceVariant, borderRadius: BorderRadius.circular(10)),
                  child: Text(code, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, letterSpacing: 1.5, color: AppColors.textPrimary)),
                ),
              ]),
            ),
            const SizedBox(height: 32),
            Text(AppLocalizations.of(context)!.showThisQrCode, textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary, fontSize: 14, height: 1.5)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: AppColors.warning.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(12)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.info_outline, color: AppColors.warning, size: 18),
                const SizedBox(width: 8),
                Text(AppLocalizations.of(context)!.deliveryConfirmedOnlyIf, style: TextStyle(fontSize: 12, color: AppColors.warning, fontWeight: FontWeight.w500)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
