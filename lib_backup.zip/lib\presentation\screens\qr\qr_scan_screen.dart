import 'package:flutter/material.dart';
import 'package:carelink_app/l10n/app_localizations.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/shared_widgets.dart';
import '../../blocs/qr/qr_bloc.dart';

/// QR scanner screen — pharmacists scan QR to verify pickup/delivery
class QrScanScreen extends StatefulWidget {
  const QrScanScreen({super.key});
  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> {
  final _manualCtrl = TextEditingController();
  bool _manualMode = true; // Default to manual since emulators lack cameras
  late final MobileScannerController _scannerController;

  @override
  void initState() {
    super.initState();
    context.read<QrBloc>().add(QrReset());
    _scannerController = MobileScannerController(
      detectionSpeed: DetectionSpeed.noDuplicates,
      facing: CameraFacing.back,
    );
  }

  @override
  void dispose() {
    _scannerController.dispose();
    _manualCtrl.dispose();
    super.dispose();
  }

  void _verify(String code) {
    if (code.isNotEmpty) context.read<QrBloc>().add(QrVerifyRequested(qrCode: code));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.scanQrCode),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 20), onPressed: () => context.pop()),
        actions: [
          TextButton.icon(
            onPressed: () => setState(() { _manualMode = !_manualMode; context.read<QrBloc>().add(QrReset()); }),
            icon: Icon(_manualMode ? Icons.qr_code_scanner : Icons.keyboard, size: 18),
            label: Text(_manualMode ? AppLocalizations.of(context)!.camera : AppLocalizations.of(context)!.manual),
          ),
        ],
      ),
      body: BlocBuilder<QrBloc, QrState>(
        builder: (context, state) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              // Scanner/Manual input area
              if (_manualMode) ...[
                Container(
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(color: AppColors.surfaceVariant, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.divider)),
                  child: Column(children: [
                    const Icon(Icons.qr_code_scanner, size: 64, color: AppColors.primary),
                    const SizedBox(height: 16),
                    Text(AppLocalizations.of(context)!.enterQrCode, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                    const SizedBox(height: 4),
                    Text(AppLocalizations.of(context)!.typeOrPasteThe, style: TextStyle(fontSize: 13, color: AppColors.textLight)),
                    const SizedBox(height: 20),
                    AppTextField(controller: _manualCtrl, hint: 'e.g. QR-DON-001', prefixIcon: Icons.qr_code),
                    const SizedBox(height: 16),
                    AppButton(text: AppLocalizations.of(context)!.verify, icon: Icons.verified, isLoading: state is QrLoading, onPressed: () => _verify(_manualCtrl.text.trim())),
                  ]),
                ),

                // Quick test codes
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.primaryContainer.withValues(alpha: 0.5), borderRadius: BorderRadius.circular(14)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(AppLocalizations.of(context)!.testQrCodes, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.primary)),
                    const SizedBox(height: 8),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      _testChip('QR-DON-001'), _testChip('QR-REQ-001'), _testChip('INVALID-QR'),
                    ]),
                  ]),
                ),
              ] else ...[
                // Real Mobile Scanner
                Container(
                  height: 300,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(20)),
                  child: MobileScanner(
                    controller: _scannerController,
                    onDetect: (capture) {
                      final List<Barcode> barcodes = capture.barcodes;
                      if (barcodes.isNotEmpty) {
                        final String code = barcodes.first.rawValue ?? '';
                        if (code.isNotEmpty) _verify(code);
                      }
                    },
                  ),
                ),
              ],

              const SizedBox(height: 24),

              // Verification result
              if (state is QrVerified) _buildResult(context, state),
              if (state is QrError) Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: AppColors.error.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14)),
                child: Row(children: [
                  const Icon(Icons.error_outline, color: AppColors.error),
                  const SizedBox(width: 12),
                  Expanded(child: Text(state.message, style: const TextStyle(color: AppColors.error))),
                ]),
              ),
            ]),
          );
        },
      ),
    );
  }

  Widget _buildResult(BuildContext context, QrVerified state) {
    if (!state.isValid) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: AppColors.error.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(16)),
        child: Column(children: [
          const Icon(Icons.cancel, color: AppColors.error, size: 48),
          const SizedBox(height: 12),
          Text(AppLocalizations.of(context)!.qrCodeNotRecognized, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16, color: AppColors.error)),
          const SizedBox(height: 4),
          Text(state.message ?? AppLocalizations.of(context)!.qrCodeNotMatch, style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
        ]),
      );
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.success.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.success.withValues(alpha: 0.3))),
      child: Column(children: [
        const Icon(Icons.check_circle, color: AppColors.success, size: 48),
        const SizedBox(height: 12),
        Text(AppLocalizations.of(context)!.qrVerified, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18, color: AppColors.success)),
        const SizedBox(height: 8),
        Text(AppLocalizations.of(context)!.typeLabel(state.type.toUpperCase()), style: TextStyle(fontWeight: FontWeight.w500, color: AppColors.textSecondary)),
        const SizedBox(height: 12),
        if (state.data.isNotEmpty) ...[
          _detailRow(AppLocalizations.of(context)!.name, state.data['medicineName'] ?? state.data['donorName'] ?? ''),
          _detailRow(AppLocalizations.of(context)!.status, state.data['status'] ?? ''),
          _detailRow(AppLocalizations.of(context)!.quantity, '${state.data['quantity'] ?? ''}'),
        ],
        const SizedBox(height: 16),
        AppButton(text: AppLocalizations.of(context)!.confirmDelivery, icon: Icons.local_shipping, onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppLocalizations.of(context)!.deliveryConfirmed), backgroundColor: AppColors.success));
          context.read<QrBloc>().add(QrReset());
          _manualCtrl.clear();
        }),
      ]),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: TextStyle(fontSize: 13, color: AppColors.textLight)),
        Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
      ]));
  }

  Widget _testChip(String code) {
    return GestureDetector(
      onTap: () { _manualCtrl.text = code; _verify(code); },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.primary.withValues(alpha: 0.3))),
        child: Text(code, style: TextStyle(fontSize: 12, color: AppColors.primary, fontWeight: FontWeight.w500)),
      ),
    );
  }
}
