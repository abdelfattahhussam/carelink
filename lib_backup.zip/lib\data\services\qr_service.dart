import 'package:dio/dio.dart';
import '../../core/constants/api_endpoints.dart';

/// QR code verification service
class QrService {
  final Dio _dio;
  QrService({required Dio dio}) : _dio = dio;

  /// Verify a scanned QR code against the backend
  Future<Map<String, dynamic>> verifyQr(String qrCode) async {
    final response = await _dio.post(
      ApiEndpoints.verifyQr,
      data: {'qrCode': qrCode},
    );

    if (response.statusCode == 200 && response.data['success'] == true) {
      return response.data;
    }
    throw Exception('QR verification failed');
  }
}
