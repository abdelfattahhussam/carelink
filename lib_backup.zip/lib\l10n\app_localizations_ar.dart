// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'كير لينك';

  @override
  String get home => 'الرئيسية';

  @override
  String get settings => 'الإعدادات';

  @override
  String get language => 'اللغة';

  @override
  String get darkMode => 'الوضع الليلي';

  @override
  String get skip => 'تخطي';

  @override
  String get next => 'التالي';

  @override
  String get getStarted => 'البدء';

  @override
  String get onboardingTitle1 => 'هبة الصحة';

  @override
  String get onboardingDesc1 =>
      'تبرع بأدويتك غير المستخدمة وغير منتهية الصلاحية لمن يحتاجها. كل تبرع يصنع فرقاً حقيقياً.';

  @override
  String get onboardingTitle2 => 'شركاء صيدلة موثوقون';

  @override
  String get onboardingDesc2 =>
      'يقوم صيادلة معتمدون بفحص وإدارة وتوزيع جميع الأدوية المتبرع بها بأمان عبر شبكتنا.';

  @override
  String get onboardingTitle3 => 'الدواء حين تحتاجه';

  @override
  String get onboardingDesc3 =>
      'يمكن للمرضى تصفح الأدوية المتاحة وطلب ما يحتاجونه بسهولة — مجاناً.';

  @override
  String get welcomeBack => 'مرحباً بك مجدداً';

  @override
  String get demoAccounts => 'حسابات تجريبية';

  @override
  String get passwordAnyValue => 'كلمة المرور: أي قيمة';

  @override
  String get createAccount => 'إنشاء حساب';

  @override
  String get backToLogin => 'العودة لتسجيل الدخول';

  @override
  String get jpgPngOrPdf => 'JPG، PNG أو PDF (حد أقصى 5MB)';

  @override
  String get quickActions => 'إجراءات سريعة';

  @override
  String get logout => 'تسجيل الخروج';

  @override
  String get pleaseSelectExpiryDate => 'يرجى اختيار تاريخ الصلاحية';

  @override
  String get donationSubmittedSuccessfully => 'تم تقديم التبرع بنجاح!';

  @override
  String get donateMedicine => 'التبرع بالدواء';

  @override
  String get yourDonationWillBe =>
      'سيتم مراجعة تبرعك من قبل الصيدلي قبل أن يصبح متاحاً.';

  @override
  String get category => 'الفئة';

  @override
  String get myDonations => 'تبرعاتي';

  @override
  String get donate => 'تبرع';

  @override
  String get qr => 'رمز QR';

  @override
  String get medicines => 'الأدوية';

  @override
  String get searchMedicines => 'البحث عن أدوية...';

  @override
  String get notifications => 'الإشعارات';

  @override
  String get manageRequests => 'إدارة الطلبات';

  @override
  String get urgent => 'عاجل';

  @override
  String get addReviewNotesOptional => 'إضافة ملاحظات مراجعة (اختياري)';

  @override
  String get cancel => 'إلغاء';

  @override
  String get reviewDonations => 'مراجعة التبرعات';

  @override
  String get reject => 'رفض';

  @override
  String get approve => 'قبول';

  @override
  String get qrCode => 'رمز الاستجابة السريعة';

  @override
  String get carelink => 'كير لينك';

  @override
  String get showThisQrCode =>
      'أظهر رمز الاستجابة السريعة هذا في الصيدلية التحقق من الاستلام.';

  @override
  String get deliveryConfirmedOnlyIf => 'يتم تأكيد التسليم فقط إذا تطابق الرمز';

  @override
  String get scanQrCode => 'مسح رمز QR';

  @override
  String get enterQrCode => 'أدخل رمز QR';

  @override
  String get typeOrPasteThe => 'اكتب أو الصق قيمة رمز QR';

  @override
  String get testQrCodes => 'رموز QR للتجربة:';

  @override
  String get cameraNotAvailableOn => 'الكاميرا غير متاحة على المحاكي';

  @override
  String get useManualModeInstead => 'استخدم الوضع اليدوي بدلاً من ذلك';

  @override
  String get qrCodeNotRecognized => 'رمز QR غير معروف';

  @override
  String get qrVerified => 'تم التحقق من الرمز!';

  @override
  String get deliveryConfirmed => 'تم تأكيد التسليم!';

  @override
  String get myRequests => 'طلباتي';

  @override
  String get showQr => 'إظهار الرمز';

  @override
  String get requestSubmitted => 'تم تقديم الطلب!';

  @override
  String get requestMedicine => 'طلب دواء';

  @override
  String get medicineNotFound => 'الدواء غير موجود';

  @override
  String get thisMedicineIsCurrently => 'هذا الدواء نفد من المخزون حالياً.';

  @override
  String get markAsUrgent => 'تحديد كعاجل';

  @override
  String get urgentRequestsGetHigher => 'الطلبات العاجلة تحصل على أولوية أعلى';

  @override
  String get allCaughtUp => 'أنهيت كل المهام!';

  @override
  String get noPendingDonations => 'لا توجد تبرعات معلقة للمراجعة.';

  @override
  String get camera => 'كاميرا';

  @override
  String get manual => 'يدوي';

  @override
  String get verify => 'تحقق';

  @override
  String get confirmDelivery => 'تأكيد التسليم';

  @override
  String typeLabel(String type) {
    return 'النوع: $type';
  }

  @override
  String get name => 'الاسم';

  @override
  String get status => 'الحالة';

  @override
  String get quantity => 'الكمية';

  @override
  String get qrCodeNotMatch => 'رمز الاستجابة السريعة هذا لا يطابق أي سجل.';

  @override
  String byNameQty(String name, String qty) {
    return 'بواسطة $name • الكمية: $qty';
  }

  @override
  String stockCount(String count) {
    return 'المخزون: $count';
  }

  @override
  String expiresAt(String date, String days) {
    return 'ينتهي في: $date ($days يوم)';
  }

  @override
  String get quantityLabel => 'الكمية';

  @override
  String get howManyDoYouNeed => 'كم تحتاج؟';

  @override
  String get enterValidQuantity => 'أدخل كمية صالحة';

  @override
  String maxAvailable(String max) {
    return 'أقصى كمية متاحة: $max';
  }

  @override
  String get reasonLabel => 'السبب';

  @override
  String get whyDoYouNeedThis => 'لماذا تحتاج هذا الدواء؟';

  @override
  String get reasonRequired => 'السبب مطلوب';

  @override
  String get submitRequest => 'تقديم الطلب';

  @override
  String get noRequestsYet => 'لا توجد طلبات بعد';

  @override
  String get browseMedicinesAndSubmit => 'تصفح الأدوية وقدم طلباً.';

  @override
  String qtyTimeAgo(String qty, String time) {
    return 'الكمية: $qty • $time';
  }

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get password => 'كلمة المرور';

  @override
  String get confirmPassword => 'تأكيد كلمة المرور';

  @override
  String get fullName => 'الاسم الكامل';

  @override
  String get phone => 'رقم الهاتف';

  @override
  String get forgotPassword => 'هل نسيت كلمة المرور؟';

  @override
  String get noAccount => 'ليس لديك حساب؟ ';

  @override
  String get hasAccount => 'لديك حساب بالفعل؟ ';

  @override
  String get signUp => 'إنشاء حساب';

  @override
  String get signIn => 'تسجيل الدخول';

  @override
  String get donor => 'متبرع';

  @override
  String get patient => 'مريض';

  @override
  String get pharmacist => 'صيدلي';

  @override
  String get selectRole => 'اختر دورك';

  @override
  String get pharmacyName => 'اسم الصيدلية';

  @override
  String get governorate => 'المحافظة';

  @override
  String get city => 'المدينة أو المركز';

  @override
  String get village => 'القرية (اختياري)';

  @override
  String get street => 'الشارع';

  @override
  String get uploadLicense => 'إدراج صورة رخصة الصيدلية';

  @override
  String get licenseRequired => 'صورة الرخصة مطلوبة لتحقق الصيدلي';

  @override
  String get address => 'العنوان';

  @override
  String get addressInfo => 'عنوان الصيدلية';

  @override
  String get profile => 'الملف الشخصي';

  @override
  String get editProfile => 'تعديل الملف الشخصي';

  @override
  String get updateProfile => 'تحديث الملف الشخصي';

  @override
  String get profileUpdatedSuccessfully => 'تم تحديث الملف الشخصي بنجاح!';

  @override
  String get changePhoto => 'تغيير الصورة';

  @override
  String get personalInfo => 'المعلومات الشخصية';

  @override
  String get dashboard => 'لوحة التحكم';

  @override
  String get welcome => 'أهلاً بك';

  @override
  String get totalDonations => 'إجمالي التبرعات';

  @override
  String get pendingReviews => 'مراجعات معلقة';

  @override
  String get activeRequests => 'الطلبات النشطة';

  @override
  String get availableMedicines => 'الأدوية المتاحة';

  @override
  String get medicineName => 'اسم الدواء';

  @override
  String get medicineDescription => 'الوصف';

  @override
  String get expiryDate => 'تاريخ الانتهاء';

  @override
  String get uploadImage => 'رفع صورة';

  @override
  String get submitDonation => 'تقديم التبرع';

  @override
  String get donationSuccess => 'تم تقديم التبرع بنجاح!';

  @override
  String get noMedicinesFound => 'لم يتم العثور على أدوية';

  @override
  String get inStock => 'متوفر';

  @override
  String get outOfStock => 'غير متوفر';

  @override
  String get markUrgent => 'تحديد كعاجل';

  @override
  String get requestReason => 'سبب الطلب';

  @override
  String get requestSuccess => 'تم تقديم الطلب بنجاح!';

  @override
  String get reviewNotes => 'ملاحظات المراجعة';

  @override
  String get noNotifications => 'لا توجد إشعارات بعد';

  @override
  String get pending => 'معلق';

  @override
  String get delivered => 'تم التسليم';

  @override
  String get expired => 'منتهي الصلاحية';

  @override
  String get genericError => 'حدث خطأ ما. يرجى المحاولة مرة أخرى.';

  @override
  String get networkError => 'لا يوجد اتصال بالإنترنت.';

  @override
  String get unauthorizedError => 'انتهت الجلسة. يرجى تسجيل الدخول مرة أخرى.';

  @override
  String get validationError => 'يرجى ملء جميع الحقول المطلوبة.';

  @override
  String signInToContinue(String appName) {
    return 'قم بتسجيل الدخول للمتابعة إلى $appName';
  }

  @override
  String get donorWelcome => 'كرمك يساعد المحتاجين. تبرع بالأدوية اليوم!';

  @override
  String get patientWelcome =>
      'اعثر على الأدوية التي تحتاجها. نحن هنا للمساعدة.';

  @override
  String get pharmacistWelcome => 'قم بمراجعة التبرعات وإدارة الطلبات بفعالية.';

  @override
  String verifiedRole(String role) {
    return 'تم التحقق من كونه $role';
  }

  @override
  String get scan => 'مسح';

  @override
  String get browse => 'تصفح';

  @override
  String get alerts => 'تنبيهات';

  @override
  String get search => 'بحث';

  @override
  String welcomeWithName(String name) {
    return 'أهلاً بك، $name! 👋';
  }

  @override
  String get tryDifferentSearch => 'جرب كلمة بحث أخرى.';

  @override
  String inStockWithCount(String count) {
    return 'متوفر ($count)';
  }

  @override
  String expDate(String date) {
    return 'تنتهي في: $date';
  }

  @override
  String get medicineNameHint => 'مثال: أموكسيسيلين 500 ملغ';

  @override
  String get descriptionHint => 'صف الدواء...';

  @override
  String get quantityHint => 'عدد الوحدات';

  @override
  String get selectExpiryDate => 'اختر تاريخ الانتهاء';

  @override
  String get medicineNameRequired => 'اسم الدواء مطلوب';

  @override
  String get descriptionRequired => 'الوصف مطلوب';

  @override
  String get expiryDateRequired => 'تاريخ الانتهاء مطلوب';

  @override
  String get catGeneral => 'عام';

  @override
  String get catAntibiotics => 'مضادات حيوية';

  @override
  String get catPainRelief => 'مسكنات ألم';

  @override
  String get catDigestive => 'جهاز هضمي';

  @override
  String get catDiabetes => 'سكري';

  @override
  String get catCardiovascular => 'قلب وأوعية دموية';

  @override
  String get catVitamins => 'فيتامينات';

  @override
  String get catOther => 'أخرى';

  @override
  String get noDonationsYet => 'لا توجد تبرعات بعد';

  @override
  String get startByDonating => 'ابدأ بالتبرع بالأدوية لمساعدة المحتاجين.';

  @override
  String get youAreAllCaughtUp => 'أنت متابع لكل شيء!';

  @override
  String get noNotificationsTitle => 'لا توجد إشعارات';

  @override
  String get secureUpload => 'رفع آمن';

  @override
  String get secureUploadDesc => 'هويتك مشفرة ومخزنة بشكل آمن.';

  @override
  String get quickReview => 'مراجعة سريعة';

  @override
  String get quickReviewDesc => 'يستغرق التحقق عادةً بضع لحظات.';

  @override
  String get oneTimeProcess => 'عملية لمرة واحدة';

  @override
  String get oneTimeProcessDesc => 'تحتاج للتحقق مرة واحدة فقط.';

  @override
  String get requestApprovedQrGenerated =>
      'تمت الموافقة على الطلب! تم إنشاء رمز QR.';

  @override
  String get requestRejected => 'تم رفض الطلب.';

  @override
  String get noRequests => 'لا توجد طلبات';

  @override
  String get noPatientRequestsAtMoment => 'لا توجد طلبات مرضى في الوقت الحالي.';

  @override
  String get approved => 'مقبول';

  @override
  String get available => 'متاح';

  @override
  String get rejected => 'مرفوض';

  @override
  String get instructionsTitle => 'تعليمات التحقق';

  @override
  String get instruction1 => 'استخدم بطاقة الهوية الحكومية الأصلية الخاصة بك.';

  @override
  String get instruction2 => 'تأكد من أن الإضاءة جيدة ولا يوجد انعكاس.';

  @override
  String get instruction3 => 'ضع البطاقة بوضوح داخل الإطار.';

  @override
  String get startVerification => 'ابدأ عملية التحقق';

  @override
  String get notifDonationApprovedTitle => 'تم قبول التبرع';

  @override
  String get notifDonationApprovedBody =>
      'تم التحقق من تبرعك بنجاح من قبل فريقنا.';

  @override
  String get notifNewRequestTitle => 'طلب جديد';

  @override
  String get notifNewRequestBody => 'هناك طلب دواء جديد ينتظر مراجعتك.';

  @override
  String get notifRequestApprovedTitle => 'تم قبول الطلب';

  @override
  String get notifRequestApprovedBody =>
      'تمت الموافقة على طلبك. يمكنك الآن استلام الدواء.';

  @override
  String get notifExpiryWarningTitle => 'تنبيه انتهاء صلاحية';

  @override
  String get notifExpiryWarningBody =>
      'بعض الأدوية في مخزونك تقترب من تاريخ انتهاء الصلاحية.';

  @override
  String get captureIdFront => 'تصوير وجه البطاقة';

  @override
  String get captureIdBack => 'تصوير ظهر البطاقة';

  @override
  String get takeSelfie => 'التقاط صورة شخصية';

  @override
  String get idFrontInstruction => 'ضع وجه بطاقة الهوية داخل الإطار.';

  @override
  String get idBackInstruction => 'ضع ظهر بطاقة الهوية داخل الإطار.';

  @override
  String get selfieInstruction =>
      'يرجى النظر مباشرة للكاميرا لمطابقة صورتك مع الهوية.';

  @override
  String stepXof3(String current) {
    return 'الخطوة $current من 3';
  }

  @override
  String get nextStep => 'الخطوة التالية';

  @override
  String get previousStep => 'الخطوة السابقة';

  @override
  String get submitForVerification => 'إرسال للتحقق';

  @override
  String get confirmIDPhoto => 'تأكيد الصورة';

  @override
  String get retakePhoto => 'إعادة التصوير';

  @override
  String get gallery => 'المعرض';

  @override
  String get fromCameraOrGallery => 'اختر من الكاميرا أو المعرض';

  @override
  String get unit => 'الوحدة';

  @override
  String get box => 'علبة';

  @override
  String get strip => 'شريط';

  @override
  String get pleaseWait => 'يرجى الانتظار، يتم توجيهك...';

  @override
  String get unauthorizedAction => 'ليس لديك صلاحية لتنفيذ هذا الإجراء.';

  @override
  String get medicineDetails => 'تفاصيل الدواء';

  @override
  String get attachPrescription => 'إرفاق الروشتة';

  @override
  String get notesForPharmacist => 'ملاحظة للصيدلي (اختياري)';

  @override
  String get prescriptionAttached => 'تم إرفاق الروشتة';

  @override
  String get accountSettings => 'إعدادات الحساب';

  @override
  String get appearance => 'المظهر';

  @override
  String get helpSupport => 'المساعدة والدعم';

  @override
  String get currentLanguage => 'اللغة الحالية';

  @override
  String get attachBoxImage => 'إرفاق صورة العلبة';

  @override
  String get boxImageRequired => 'صورة العلبة مطلوبة';

  @override
  String get boxImageAttached => 'تم إرفاق صورة العلبة';

  @override
  String get nationalId => 'الرقم القومي';

  @override
  String get nationalIdRequired => 'الرقم القومي مطلوب';

  @override
  String get nationalIdInvalid => 'يجب أن يتكون الرقم القومي من 14 رقم بالظبط';

  @override
  String get patientNationalId => 'الرقم القومي للمريض';

  @override
  String get nationalIdImmutableNote =>
      'لا يمكن تعديل الرقم القومي بعد التسجيل';
}
