import 'package:equatable/equatable.dart';
import 'package:carelink_app/data/models/medicine_unit.dart';

/// Donation model — tracks a medicine donation through the review pipeline
class DonationModel extends Equatable {
  final String id;
  final String medicineId;
  final String medicineName;
  final String donorId;
  final String donorName;
  final String status; // 'pending', 'approved', 'rejected'
  final String? qrCode; // Generated only after approval
  final int quantity;
  final MedicineUnit unit;
  final String notes;
  final String? boxImagePath; // Added box image path
  final String? reviewedBy;
  final DateTime createdAt;

  const DonationModel({
    required this.id,
    required this.medicineId,
    required this.medicineName,
    required this.donorId,
    required this.donorName,
    required this.status,
    this.qrCode,
    required this.quantity,
    required this.unit,
    required this.notes,
    this.boxImagePath,
    this.reviewedBy,
    required this.createdAt,
  });

  bool get isPending => status == 'pending';
  bool get isApproved => status == 'approved';
  bool get isRejected => status == 'rejected';
  bool get hasQrCode => qrCode != null && qrCode!.isNotEmpty;

  factory DonationModel.fromJson(Map<String, dynamic> json) {
    return DonationModel(
      id: json['id'] ?? '',
      medicineId: json['medicineId'] ?? '',
      medicineName: json['medicineName'] ?? '',
      donorId: json['donorId'] ?? '',
      donorName: json['donorName'] ?? '',
      status: json['status'] ?? 'pending',
      qrCode: json['qrCode'],
      quantity: json['quantity'] ?? 0,
      unit: MedicineUnit.fromJson(json['unit']?.toString()),
      notes: json['notes'] ?? '',
      boxImagePath: json['boxImagePath'],
      reviewedBy: json['reviewedBy'],
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'medicineId': medicineId,
      'medicineName': medicineName,
      'donorId': donorId,
      'donorName': donorName,
      'status': status,
      'qrCode': qrCode,
      'quantity': quantity,
      'unit': unit.toJson(),
      'notes': notes,
      'boxImagePath': boxImagePath,
      'reviewedBy': reviewedBy,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [
        id,
        medicineId,
        medicineName,
        donorId,
        donorName,
        status,
        qrCode,
        quantity,
        unit,
        notes,
        boxImagePath,
        reviewedBy,
        createdAt,
      ];
}
