import 'package:dio/dio.dart';
import 'package:uuid/uuid.dart';

/// Mock interceptor that simulates backend API responses.
/// Remove this interceptor and point to real base URL for production.
class MockInterceptor extends Interceptor {
  // In-memory mock data stores
  static final List<Map<String, dynamic>> _users = [
    {
      'id': 'user-1',
      'name': 'Ahmed Hassan',
      'email': 'donor@test.com',
      'phone': '+201234567890',
      'role': 'donor',
      'status': 'verified',
      'token': 'mock-jwt-token-donor',
      'createdAt': DateTime.now().subtract(const Duration(days: 30)).toIso8601String(),
    },
    {
      'id': 'user-2',
      'name': 'Sara Mohamed',
      'email': 'patient@test.com',
      'phone': '+201098765432',
      'role': 'patient',
      'status': 'verified',
      'token': 'mock-jwt-token-patient',
      'createdAt': DateTime.now().subtract(const Duration(days: 20)).toIso8601String(),
    },
    {
      'id': 'user-3',
      'name': 'Dr. Khaled Ali',
      'email': 'pharmacist@test.com',
      'phone': '+201112233445',
      'role': 'pharmacist',
      'status': 'verified',
      'token': 'mock-jwt-token-pharmacist',
      'createdAt': DateTime.now().subtract(const Duration(days: 60)).toIso8601String(),
    },
  ];

  static final List<Map<String, dynamic>> _medicines = [
    {
      'id': 'med-1',
      'name': 'Amoxicillin 500mg',
      'description': 'Antibiotic capsules for bacterial infections',
      'expiryDate': DateTime.now().add(const Duration(days: 180)).toIso8601String(),
      'quantity': 24,
      'unit': 'strip',
      'donorId': 'user-1',
      'donorName': 'Ahmed Hassan',
      'status': 'approved',
      'imageUrl': '',
      'category': 'Antibiotics',
      'createdAt': DateTime.now().subtract(const Duration(days: 5)).toIso8601String(),
    },
    {
      'id': 'med-2',
      'name': 'Paracetamol 500mg',
      'description': 'Pain reliever and fever reducer tablets',
      'expiryDate': DateTime.now().add(const Duration(days: 365)).toIso8601String(),
      'quantity': 50,
      'unit': 'box',
      'donorId': 'user-1',
      'donorName': 'Ahmed Hassan',
      'status': 'approved',
      'imageUrl': '',
      'category': 'Pain Relief',
      'createdAt': DateTime.now().subtract(const Duration(days: 3)).toIso8601String(),
    },
    {
      'id': 'med-3',
      'name': 'Omeprazole 20mg',
      'description': 'Proton pump inhibitor for acid reflux',
      'expiryDate': DateTime.now().add(const Duration(days: 90)).toIso8601String(),
      'quantity': 14,
      'unit': 'strip',
      'donorId': 'user-1',
      'donorName': 'Ahmed Hassan',
      'status': 'approved',
      'imageUrl': '',
      'category': 'Digestive',
      'createdAt': DateTime.now().subtract(const Duration(days: 2)).toIso8601String(),
    },
    {
      'id': 'med-4',
      'name': 'Metformin 850mg',
      'description': 'Oral diabetes medicine to control blood sugar',
      'expiryDate': DateTime.now().add(const Duration(days: 240)).toIso8601String(),
      'quantity': 30,
      'unit': 'box',
      'donorId': 'user-1',
      'donorName': 'Ahmed Hassan',
      'status': 'pending',
      'imageUrl': '',
      'category': 'Diabetes',
      'createdAt': DateTime.now().subtract(const Duration(days: 1)).toIso8601String(),
    },
    {
      'id': 'med-5',
      'name': 'Losartan 50mg',
      'description': 'Angiotensin receptor blocker for hypertension',
      'expiryDate': DateTime.now().subtract(const Duration(days: 10)).toIso8601String(),
      'quantity': 0,
      'unit': 'box',
      'donorId': 'user-1',
      'donorName': 'Ahmed Hassan',
      'status': 'expired',
      'imageUrl': '',
      'category': 'Cardiovascular',
      'createdAt': DateTime.now().subtract(const Duration(days: 200)).toIso8601String(),
    },
    {
      'id': 'med-6',
      'name': 'Ibuprofen 400mg',
      'description': 'Non-steroidal anti-inflammatory drug',
      'expiryDate': DateTime.now().add(const Duration(days: 270)).toIso8601String(),
      'quantity': 36,
      'unit': 'strip',
      'donorId': 'user-1',
      'donorName': 'Ahmed Hassan',
      'status': 'approved',
      'imageUrl': '',
      'category': 'Pain Relief',
      'createdAt': DateTime.now().subtract(const Duration(hours: 12)).toIso8601String(),
    },
  ];

  static final List<Map<String, dynamic>> _donations = [
    {
      'id': 'don-1',
      'medicineId': 'med-1',
      'medicineName': 'Amoxicillin 500mg',
      'donorId': 'user-1',
      'donorName': 'Ahmed Hassan',
      'status': 'approved',
      'qrCode': 'QR-DON-001',
      'quantity': 24,
      'unit': 'strip',
      'notes': '',
      'reviewedBy': 'user-3',
      'createdAt': DateTime.now().subtract(const Duration(days: 5)).toIso8601String(),
    },
    {
      'id': 'don-2',
      'medicineId': 'med-4',
      'medicineName': 'Metformin 850mg',
      'donorId': 'user-1',
      'donorName': 'Ahmed Hassan',
      'status': 'pending',
      'qrCode': null,
      'quantity': 30,
      'unit': 'box',
      'notes': '',
      'reviewedBy': null,
      'createdAt': DateTime.now().subtract(const Duration(days: 1)).toIso8601String(),
    },
  ];

  static final List<Map<String, dynamic>> _requests = [
    {
      'id': 'req-1',
      'patientId': 'user-2',
      'patientName': 'Sara Mohamed',
      'medicineId': 'med-2',
      'medicineName': 'Paracetamol 500mg',
      'quantity': 10,
      'status': 'approved',
      'isUrgent': false,
      'reason': 'Needed for chronic pain management',
      'qrCode': 'QR-REQ-001',
      'createdAt': DateTime.now().subtract(const Duration(days: 2)).toIso8601String(),
    },
    {
      'id': 'req-2',
      'patientId': 'user-2',
      'patientName': 'Sara Mohamed',
      'medicineId': 'med-3',
      'medicineName': 'Omeprazole 20mg',
      'quantity': 7,
      'status': 'pending',
      'isUrgent': true,
      'reason': 'Urgent: severe acid reflux episodes',
      'qrCode': null,
      'createdAt': DateTime.now().subtract(const Duration(hours: 6)).toIso8601String(),
    },
  ];

  static final List<Map<String, dynamic>> _notifications = [
    {
      'id': 'notif-1',
      'title': 'Donation Approved',
      'body': 'Your donation of Amoxicillin 500mg has been approved by the pharmacist.',
      'type': 'donationApproved',
      'isRead': false,
      'userId': 'user-1',
      'targetRole': 'donor',
      'createdAt': DateTime.now().subtract(const Duration(hours: 2)).toIso8601String(),
    },
    {
      'id': 'notif-2',
      'title': 'New Request',
      'body': 'Sara Mohamed has requested Paracetamol 500mg.',
      'type': 'newRequest',
      'isRead': false,
      'userId': null, // Role-wide notification
      'targetRole': 'pharmacist',
      'createdAt': DateTime.now().subtract(const Duration(hours: 3)).toIso8601String(),
    },
    {
      'id': 'notif-3',
      'title': 'Request Approved',
      'body': 'Your request for Paracetamol 500mg has been approved. Show QR code for pickup.',
      'type': 'requestApproved',
      'isRead': true,
      'userId': 'user-2', // Private notification
      'targetRole': 'patient',
      'createdAt': DateTime.now().subtract(const Duration(days: 1)).toIso8601String(),
    },
    {
      'id': 'notif-4',
      'title': 'Medicine Expiring Soon',
      'body': 'Omeprazole 20mg will expire in 90 days.',
      'type': 'expiryWarning',
      'isRead': false,
      'userId': null, // Role-wide notification
      'targetRole': 'pharmacist',
      'createdAt': DateTime.now().subtract(const Duration(hours: 1)).toIso8601String(),
    },
  ];

  final _uuid = const Uuid();

  @override
  void onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    // Simulate network latency
    await Future.delayed(const Duration(milliseconds: 500));

    final path = options.path;
    final method = options.method;

    try {
      Response response;

      // ─── AUTH ───
      if (path.contains('/auth/login') && method == 'POST') {
        response = _handleLogin(options);
      } else if (path.contains('/auth/register') && method == 'POST') {
        response = _handleRegister(options);
      } else if (path.contains('/auth/profile') && method == 'GET') {
        response = _handleGetProfile(options);
      } else if (path.contains('/auth/profile') && method == 'POST') {
        response = _handleUpdateProfile(options);

      // ─── DONATIONS ───
      } else if (path.contains('/donations/pending') && method == 'GET') {
        response = _handleGetPendingDonations(options);
      } else if (path.contains('/donations') && method == 'GET' && !path.contains('/donations/')) {
        response = _handleGetDonations(options);
      } else if (path.contains('/donations') && method == 'POST') {
        response = _handleCreateDonation(options);

      // ─── MEDICINES ───
      } else if (path.contains('/medicines/search') && method == 'GET') {
        response = _handleSearchMedicines(options);
      } else if (path.contains('/medicines') && method == 'GET') {
        response = _handleGetMedicines(options);

      // ─── REQUESTS ───
      } else if (path.contains('/requests') && method == 'GET') {
        response = _handleGetRequests(options);
      } else if (path.contains('/requests') && method == 'POST') {
        response = _handleCreateRequest(options);

      // ─── PHARMACIST ───
      } else if (path.contains('/pharmacist/review') && method == 'POST') {
        response = _handleReviewDonation(options);
      } else if (path.contains('/pharmacist/approve-request') && method == 'POST') {
        response = _handleApproveRequest(options);

      // ─── QR ───
      } else if (path.contains('/qr/verify') && method == 'POST') {
        response = _handleVerifyQr(options);

      // ─── NOTIFICATIONS ───
      } else if (path.contains('/notifications/read/') && method == 'POST') {
        response = _handleMarkRead(options);
      } else if (path.contains('/notifications') && method == 'GET') {
        response = _handleGetNotifications(options);
      } else {
        response = Response(
          requestOptions: options,
          statusCode: 404,
          data: {'error': 'Endpoint not found'},
        );
      }

      handler.resolve(response);
    } catch (e) {
      handler.resolve(Response(
        requestOptions: options,
        statusCode: 500,
        data: {'error': e.toString()},
      ));
    }
  }

  // ─── AUTH HANDLERS ───

  Response _handleLogin(RequestOptions options) {
    final data = options.data as Map<String, dynamic>?;
    final email = data?['email'] ?? '';
    final password = data?['password'] ?? '';

    if (email.isEmpty || password.isEmpty) {
      return Response(
        requestOptions: options,
        statusCode: 400,
        data: {'error': 'Email and password are required'},
      );
    }

    final user = _users.where((u) => u['email'] == email).firstOrNull;
    if (user == null) {
      return Response(
        requestOptions: options,
        statusCode: 401,
        data: {'error': 'Invalid email or password'},
      );
    }

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {
        'success': true,
        'data': Map<String, dynamic>.from(user),
      },
    );
  }

  Response _handleRegister(RequestOptions options) {
    final data = options.data as Map<String, dynamic>?;
    final id = 'user-${_uuid.v4().substring(0, 8)}';
    final newUser = {
      'id': id,
      'name': data?['name'] ?? '',
      'email': data?['email'] ?? '',
      'phone': data?['phone'] ?? '',
      'nationalId': data?['nationalId'] ?? '',
      'role': data?['role'] ?? 'patient',
      'status': 'verified',
      'token': 'mock-jwt-token-$id',
      'createdAt': DateTime.now().toIso8601String(),
    };
    _users.add(newUser);

    return Response(
      requestOptions: options,
      statusCode: 201,
      data: {
        'success': true,
        'data': Map<String, dynamic>.from(newUser),
      },
    );
  }

  Response _handleGetProfile(RequestOptions options) {
    final token = options.headers['Authorization']?.toString().replaceFirst('Bearer ', '') ?? '';
    final user = _users.where((u) => u['token'] == token).firstOrNull;

    if (user == null) {
      return Response(requestOptions: options, statusCode: 401, data: {'error': 'Unauthorized'});
    }

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': Map<String, dynamic>.from(user)},
    );
  }

  Response _handleUpdateProfile(RequestOptions options) {
    final data = options.data as Map<String, dynamic>?;
    final userId = data?['userId'] ?? '';

    final index = _users.indexWhere((u) => u['id'] == userId);
    if (index < 0) {
      return Response(
        requestOptions: options,
        statusCode: 404,
        data: {'error': 'User not found'},
      );
    }

    // Update user in mock store
    if (data?['name'] != null) _users[index]['name'] = data!['name'];
    if (data?['email'] != null) _users[index]['email'] = data!['email'];
    if (data?['phone'] != null) _users[index]['phone'] = data!['phone'];
    if (data?['pharmacyName'] != null) _users[index]['pharmacyName'] = data!['pharmacyName'];
    if (data?['governorate'] != null) _users[index]['governorate'] = data!['governorate'];
    if (data?['city'] != null) _users[index]['city'] = data!['city'];
    if (data?['village'] != null) _users[index]['village'] = data!['village'];
    if (data?['street'] != null) _users[index]['street'] = data!['street'];
    if (data?['profilePicturePath'] != null) _users[index]['profilePicturePath'] = data!['profilePicturePath'];

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {
        'success': true,
        'data': Map<String, dynamic>.from(_users[index]),
      },
    );
  }

  // ─── DONATION HANDLERS ───

  Response _handleGetDonations(RequestOptions options) {
    final token = options.headers['Authorization']?.toString().replaceFirst('Bearer ', '') ?? '';
    final user = _users.where((u) => u['token'] == token).firstOrNull;

    List<Map<String, dynamic>> result = _donations;
    if (user != null && user['role'] == 'donor') {
      result = _donations.where((d) => d['donorId'] == user['id']).toList();
    }

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': result.map((d) => Map<String, dynamic>.from(d)).toList()},
    );
  }

  Response _handleGetPendingDonations(RequestOptions options) {
    final pending = _donations.where((d) => d['status'] == 'pending').toList();
    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': pending.map((d) => Map<String, dynamic>.from(d)).toList()},
    );
  }

  Response _handleCreateDonation(RequestOptions options) {
    final data = options.data as Map<String, dynamic>?;
    final medId = 'med-${_uuid.v4().substring(0, 8)}';
    final donId = 'don-${_uuid.v4().substring(0, 8)}';

    final token = options.headers['Authorization']?.toString().replaceFirst('Bearer ', '') ?? '';
    final user = _users.where((u) => u['token'] == token).firstOrNull;

    // Create the medicine entry
    final medicine = {
      'id': medId,
      'name': data?['name'] ?? '',
      'description': data?['description'] ?? '',
      'expiryDate': data?['expiryDate'] ?? DateTime.now().add(const Duration(days: 180)).toIso8601String(),
      'quantity': data?['quantity'] ?? 1,
      'unit': data?['unit'] ?? 'box', // Handle unit
      'donorId': user?['id'] ?? 'unknown',
      'donorName': user?['name'] ?? 'Unknown',
      'status': 'pending',
      'imageUrl': '',
      'category': data?['category'] ?? 'General',
      'createdAt': DateTime.now().toIso8601String(),
    };
    _medicines.add(medicine);

    // Create matching donation record
    final donation = {
      'id': donId,
      'medicineId': medId,
      'medicineName': data?['name'] ?? '',
      'donorId': user?['id'] ?? 'unknown',
      'donorName': user?['name'] ?? 'Unknown',
      'status': 'pending',
      'qrCode': null,
      'quantity': data?['quantity'] ?? 1,
      'unit': data?['unit'] ?? 'box', // Handle unit
      'notes': '',
      'reviewedBy': null,
      'createdAt': DateTime.now().toIso8601String(),
    };
    _donations.add(donation);

    return Response(
      requestOptions: options,
      statusCode: 201,
      data: {'success': true, 'data': Map<String, dynamic>.from(donation)},
    );
  }

  // ─── MEDICINE HANDLERS ───

  Response _handleGetMedicines(RequestOptions options) {
    final approved = _medicines.where((m) => m['status'] == 'approved').toList();
    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': approved.map((m) => Map<String, dynamic>.from(m)).toList()},
    );
  }

  Response _handleSearchMedicines(RequestOptions options) {
    final query = (options.queryParameters['q'] ?? '').toString().toLowerCase();
    final results = _medicines
        .where((m) =>
            m['status'] == 'approved' &&
            (m['name'].toString().toLowerCase().contains(query) ||
             m['category'].toString().toLowerCase().contains(query)))
        .toList();

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': results.map((m) => Map<String, dynamic>.from(m)).toList()},
    );
  }

  // ─── REQUEST HANDLERS ───

  Response _handleGetRequests(RequestOptions options) {
    final token = options.headers['Authorization']?.toString().replaceFirst('Bearer ', '') ?? '';
    final user = _users.where((u) => u['token'] == token).firstOrNull;

    List<Map<String, dynamic>> result = _requests;
    if (user != null && user['role'] == 'patient') {
      result = _requests.where((r) => r['patientId'] == user['id']).toList();
    }

    // Sort: urgent first, then by date
    result.sort((a, b) {
      if (a['isUrgent'] == true && b['isUrgent'] != true) return -1;
      if (b['isUrgent'] == true && a['isUrgent'] != true) return 1;
      return DateTime.parse(b['createdAt']).compareTo(DateTime.parse(a['createdAt']));
    });

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': result.map((r) => Map<String, dynamic>.from(r)).toList()},
    );
  }

  Response _handleCreateRequest(RequestOptions options) {
    final data = options.data as Map<String, dynamic>?;
    final token = options.headers['Authorization']?.toString().replaceFirst('Bearer ', '') ?? '';
    final user = _users.where((u) => u['token'] == token).firstOrNull;

    // Check stock
    final med = _medicines.where((m) => m['id'] == data?['medicineId']).firstOrNull;
    if (med == null || (med['quantity'] as int) <= 0) {
      return Response(
        requestOptions: options,
        statusCode: 400,
        data: {'error': 'Medicine is out of stock'},
      );
    }

    final request = {
      'patientId': user?['id'] ?? 'unknown',
      'patientName': user?['name'] ?? 'Unknown',
      'patientNationalId': user?['nationalId'] ?? 'Unknown',
      'medicineId': data?['medicineId'] ?? '',
      'medicineName': med['name'],
      'quantity': data?['quantity'] ?? 1,
      'unit': med['unit'] ?? 'box', // Propagate unit from medicine
      'status': 'pending',
      'isUrgent': data?['isUrgent'] ?? false,
      'reason': data?['reason'] ?? '',
      'qrCode': null,
      'createdAt': DateTime.now().toIso8601String(),
    };
    _requests.add(request);

    return Response(
      requestOptions: options,
      statusCode: 201,
      data: {'success': true, 'data': Map<String, dynamic>.from(request)},
    );
  }

  // ─── PHARMACIST HANDLERS ───

  Response _handleReviewDonation(RequestOptions options) {
    final data = options.data as Map<String, dynamic>?;
    final donationId = data?['donationId'] ?? '';
    final action = data?['action'] ?? ''; // 'approve' or 'reject'

    final donIndex = _donations.indexWhere((d) => d['id'] == donationId);
    if (donIndex < 0) {
      return Response(requestOptions: options, statusCode: 404, data: {'error': 'Donation not found'});
    }

    if (action == 'approve') {
      _donations[donIndex]['status'] = 'approved';
      _donations[donIndex]['qrCode'] = 'QR-DON-${_uuid.v4().substring(0, 6).toUpperCase()}';

      // Also update medicine status
      final medId = _donations[donIndex]['medicineId'];
      final medIndex = _medicines.indexWhere((m) => m['id'] == medId);
      if (medIndex >= 0) {
        _medicines[medIndex]['status'] = 'approved';
      }
    } else {
      _donations[donIndex]['status'] = 'rejected';
    }
    _donations[donIndex]['notes'] = data?['notes'] ?? '';

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': Map<String, dynamic>.from(_donations[donIndex])},
    );
  }

  Response _handleApproveRequest(RequestOptions options) {
    final data = options.data as Map<String, dynamic>?;
    final requestId = data?['requestId'] ?? '';
    final action = data?['action'] ?? '';

    final reqIndex = _requests.indexWhere((r) => r['id'] == requestId);
    if (reqIndex < 0) {
      return Response(requestOptions: options, statusCode: 404, data: {'error': 'Request not found'});
    }

    if (action == 'approve') {
      _requests[reqIndex]['status'] = 'approved';
      _requests[reqIndex]['qrCode'] = 'QR-REQ-${_uuid.v4().substring(0, 6).toUpperCase()}';

      // Decrease stock
      final medId = _requests[reqIndex]['medicineId'];
      final medIndex = _medicines.indexWhere((m) => m['id'] == medId);
      if (medIndex >= 0) {
        final currentQty = _medicines[medIndex]['quantity'] as int;
        final requestedQty = _requests[reqIndex]['quantity'] as int;
        _medicines[medIndex]['quantity'] = (currentQty - requestedQty).clamp(0, currentQty);
      }
    } else {
      _requests[reqIndex]['status'] = 'rejected';
    }

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': Map<String, dynamic>.from(_requests[reqIndex])},
    );
  }

  // ─── QR HANDLERS ───

  Response _handleVerifyQr(RequestOptions options) {
    final data = options.data as Map<String, dynamic>?;
    final qrCode = data?['qrCode'] ?? '';

    // Check donations
    final donation = _donations.where((d) => d['qrCode'] == qrCode).firstOrNull;
    if (donation != null) {
      return Response(
        requestOptions: options,
        statusCode: 200,
        data: {
          'success': true,
          'verified': true,
          'type': 'donation',
          'data': Map<String, dynamic>.from(donation),
        },
      );
    }

    // Check requests
    final request = _requests.where((r) => r['qrCode'] == qrCode).firstOrNull;
    if (request != null) {
      return Response(
        requestOptions: options,
        statusCode: 200,
        data: {
          'success': true,
          'verified': true,
          'type': 'request',
          'data': Map<String, dynamic>.from(request),
        },
      );
    }

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'verified': false, 'message': 'QR code not recognized'},
    );
  }

  // ─── NOTIFICATION HANDLERS ───

  Response _handleGetNotifications(RequestOptions options) {
    final token = options.headers['Authorization']?.toString().replaceFirst('Bearer ', '') ?? '';
    final user = _users.where((u) => u['token'] == token).firstOrNull;

    if (user == null) {
      return Response(requestOptions: options, statusCode: 401, data: {'error': 'Unauthorized'});
    }

    // Filter by userId OR targetRole matching user's role
    final List<Map<String, dynamic>> result = _notifications.where((n) {
      final isForThisUser = n['userId'] == user['id'];
      final isRoleWide = n['userId'] == null && n['targetRole'] == user['role'];
      return isForThisUser || isRoleWide;
    }).toList();

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true, 'data': result.map((n) => Map<String, dynamic>.from(n)).toList()},
    );
  }

  Response _handleMarkRead(RequestOptions options) {
    final id = options.path.split('/').last;
    final index = _notifications.indexWhere((n) => n['id'] == id);
    if (index >= 0) {
      _notifications[index] = Map<String, dynamic>.from(_notifications[index])
        ..['isRead'] = true; // ✅ mark as read, keep in list
    }

    return Response(
      requestOptions: options,
      statusCode: 200,
      data: {'success': true},
    );
  }
}
